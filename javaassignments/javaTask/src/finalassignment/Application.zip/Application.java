package finalassignment;

public interface Application {
	
	public void webBrowser();


}
