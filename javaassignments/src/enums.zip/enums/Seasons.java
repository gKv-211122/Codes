package enums;

public enum Seasons {
	
	WINTER, SPRING, SUMMER, FALL;
	
	public static void main(String[] args) { 
		
		Season s=Season.WINTER;  
		
		System.out.println(s);  
	}  

}
