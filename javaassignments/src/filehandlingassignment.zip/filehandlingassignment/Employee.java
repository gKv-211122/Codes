package filehandlingassignment;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Employee {
	
	public void createFile() {
		
		
	}
	
	public void writeFile() throws IOException {
		
		
	}
	
	public void readFile() throws FileNotFoundException {
		
		
	}

}
