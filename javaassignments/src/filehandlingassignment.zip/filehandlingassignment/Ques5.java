package filehandlingassignment;

public class Ques5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		

	}

}
